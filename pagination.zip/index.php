<?php
include_once "dbc.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

      
</head>
<body class="teal lighten-2">

<?php
if(isset($_GET['page']))
{
$page=$_GET['page'];
$page=mysqli_real_escape_string($conn,$page);
$page=htmlentities($page);
}
else
{
$page=1;
}
$sql="select * from posts";
$res=mysqli_query($conn,$sql);
$count=mysqli_num_rows($res);
$per_page=2;
$no_of_page=ceil($count/$per_page);
$start=($page-1)*$per_page;
$sql="select * from posts limit $start,$per_page";
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res)>0)
{
?>
<div class="row">
<div class="col l6 offset-l3">
<?php
while($x=mysqli_fetch_assoc($res))
{
    ?>
    <div class="card-panel">
    <p style="font-size:1.4rem"><a href=""><?php echo $x['title'];?></a></p>
    <span class="grey-text text-darken-2"><?php 
    $content=substr($x['content'],0,100);
    echo $content;
    ?>
    </span>
    <br>
   <span class="grey-text"> by <?php echo $x['author'];?> on <?php echo $x['publish_date'];?></span>
    </div>
    <?php
}
?>

 <ul class="pagination">
    <li 
<?php
    if($page==1)
    echo "class='disabled'";
?>
    ><a 
    
    
    href="index.php?page=<?php
echo $page-1;
    ?>
    "
    
    
    
    ><i class="material-icons">chevron_left</i></a></li>
   <?php
   for($i=1;$i<=$no_of_page;$i++)
   {
       ?>
       <li 
       <?php 

       if($page==$i)
       echo "class='active'";
       ?>
       
       ><a href="index.php?page=<?php echo $i;?>"><?php echo $i;?></a></li>
       <?php
   }
   ?>

    <li 
    <?php
    if($page==$no_of_page)
    echo "class='disabled'";
?>
    
    ><a   href="index.php?page=<?php
echo $page+1;
    ?>"><i class="material-icons">chevron_right</i></a></li>
  </ul>

</div>
</div>
<?php
}
else
{
    header("Location: index.php?page=1");
}
?>

 <!-- Compiled and minified JavaScript -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>